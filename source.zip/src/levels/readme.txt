several levels for the demonstration
more can be created, following the same structure as used
level files must be 20 * 10 tokens, seperated by a single space
the number of levels must be adjusted in the Map class
possible tokens are "flower","coin","box","wall","floor","tunnel","goomba","bird","empty"